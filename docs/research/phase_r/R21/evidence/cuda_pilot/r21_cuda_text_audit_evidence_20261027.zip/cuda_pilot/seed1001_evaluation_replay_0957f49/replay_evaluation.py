#!/usr/bin/env python3
"""Replay R21 CPU-side evaluation from an already executed CUDA case."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shlex
import sys

from scripts.phase_r import run_r21_cuda_pilot as pilot


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-root", type=Path, required=True)
    parser.add_argument("--execution-manifest", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    case_root = args.case_root.expanduser().resolve()
    execution_manifest_path = args.execution_manifest.expanduser().resolve()
    output_root = args.output_root.expanduser().resolve()
    case_manifest_path = case_root / "case_manifest.json"
    if not case_manifest_path.is_file() or not execution_manifest_path.is_file():
        parser.error("case_manifest.json and the original execution manifest are required")
    retained_script = Path(__file__).resolve()
    if output_root.exists() and any(item.resolve() != retained_script for item in output_root.iterdir()):
        parser.error(f"refusing to overwrite non-empty output root: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)

    case = pilot.stage1._read_json(case_manifest_path)
    execution = pilot.stage1._read_json(execution_manifest_path)
    if case.get("scene_identity", {}).get("seed") != execution.get("design", {}).get("seed"):
        parser.error("case seed does not match the original execution manifest")
    if not execution.get("status_labels", {}).get("EXECUTED"):
        parser.error("the source manifest does not prove CUDA Production execution")

    bundles = pilot._build_bundles(case_root, case)
    closure_rows = pilot._input_closure_rows(case)
    evaluation = pilot._evaluate_case(case_root, case, bundles)
    evaluation_dir = output_root / "evaluation"
    for name, rows in (
        ("r21_task_metrics.csv", evaluation["task_metrics"]),
        ("r21_task_metrics_by_condition.csv", evaluation["task_metrics_by_condition"]),
        ("r21_truth_opportunity_audit.csv", evaluation["truth_opportunity_audit"]),
        ("r21_doppler_opportunity_audit.csv", evaluation["doppler_opportunity_audit"]),
        ("r21_track_semantics.csv", evaluation["track_semantics"]),
        ("r21_parameter_records.csv", evaluation["parameter_records"]),
        ("r21_h0_descriptive_metrics.csv", evaluation["h0_descriptive_metrics"]),
        ("r21_corrected_input_closure.csv", closure_rows),
    ):
        pilot._write_csv(evaluation_dir / name, rows)
    pilot._write_json(
        evaluation_dir / "r21_condition_auxiliary_metrics.json",
        evaluation["condition_auxiliary"],
    )

    invalid = sum(row.get("status") == "NOT_EVALUABLE" for row in evaluation["truth_opportunity_audit"])
    blank = sum(
        row.get("status") in {"EVALUABLE", "EVALUABLE_WITH_EXCLUDED_OPPORTUNITIES"}
        and row.get("hits") is None
        for row in evaluation["task_metrics"]
    )
    all_on_evaluable = pilot._all_on_task_conditions_evaluable(
        evaluation["task_metrics_by_condition"]
    )
    evaluable = all_on_evaluable and invalid == 0 and blank == 0
    closure_status_counts = {
        status: sum(row.get("status") == status for row in closure_rows)
        for status in sorted({str(row.get("status")) for row in closure_rows})
    }
    manifest = {
        "schema_version": 1,
        "experiment": "PGRCC R21 seed1001 CPU evaluation replay from completed Native CUDA outputs",
        "status": "evaluation_replay_completed" if evaluable else "evaluation_replay_with_gaps",
        "evaluation_only_replay": True,
        "new_cuda_execution_performed": False,
        "execution_manifest": pilot._file_record(execution_manifest_path),
        "execution_manifest_original_status": execution.get("status"),
        "execution_manifest_original_failure": execution.get("failure"),
        "case_manifest": pilot._file_record(case_manifest_path),
        "case_root": pilot.adapter.audit_path(case_root),
        "seed": case["scene_identity"]["seed"],
        "execution_source_commit": execution.get("git", {}).get("commit"),
        "evaluation_source_commit": pilot._git_identity()["commit"],
        "evaluation_source_file": pilot._file_record(Path(pilot.__file__)),
        "command": shlex.join([sys.executable, *sys.argv]),
        "bundle_count": len(bundles),
        "known_correction_physical_closure": case.get("known_correction_physical_closure"),
        "all_condition_processing_chain_comparability": case.get("all_condition_processing_chain_comparability"),
        "corrected_input_distance_status_counts": closure_status_counts,
        "evaluation_summary": {
            "r21_evaluator_version": "r21-task-eval-v3",
            "task_metric_rows": len(evaluation["task_metrics"]),
            "truth_opportunity_rows": len(evaluation["truth_opportunity_audit"]),
            "truth_opportunities_not_evaluable": invalid,
            "evaluable_task_rows_with_missing_hits": blank,
            "all_ON_task_conditions_evaluable": all_on_evaluable,
            "statistical_pd_pfa_claim": False,
        },
        "status_labels": {
            "IMPLEMENTED": True,
            "EXECUTED": bool(execution.get("status_labels", {}).get("EXECUTED")),
            "EVALUABLE": evaluable,
            "PERFORMANCE_VERIFIED": False,
            "note": "single seed is feasibility evidence; no statistical Pd/Pfa claim",
        },
        "evaluation_files": [
            "evaluation/r21_task_metrics.csv",
            "evaluation/r21_task_metrics_by_condition.csv",
            "evaluation/r21_truth_opportunity_audit.csv",
            "evaluation/r21_doppler_opportunity_audit.csv",
            "evaluation/r21_track_semantics.csv",
            "evaluation/r21_parameter_records.csv",
            "evaluation/r21_h0_descriptive_metrics.csv",
            "evaluation/r21_corrected_input_closure.csv",
            "evaluation/r21_condition_auxiliary_metrics.json",
        ],
    }
    pilot._write_json(output_root / "manifest.json", manifest)
    print(json.dumps({
        "status": manifest["status"],
        "seed": manifest["seed"],
        "status_labels": manifest["status_labels"],
        "output_root": pilot.adapter.audit_path(output_root),
    }, ensure_ascii=False, indent=2))
    return 0 if evaluable else 2


if __name__ == "__main__":
    raise SystemExit(main())
